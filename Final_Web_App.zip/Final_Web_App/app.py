from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Set latitude and longitude values to display GPS loc
default_latitude = 54.0
default_longitude = 80.0

# Route to render the HTML template with default latitude and longitude
@app.route('/')
def index():
    return render_template('Final_Web_App.html', default_latitude=default_latitude, default_longitude=default_longitude)

# Route to update latitude and longitude values
@app.route('/update_coordinates', methods=['POST'])
def update_coordinates():
    global default_latitude, default_longitude

    latitude = request.form.get('latitude')
    longitude = request.form.get('longitude')

    # Update the global values
    default_latitude = float(latitude)
    default_longitude = float(longitude)

    return 'Coordinates updated successfully'

# Route to get current coordinates
@app.route('/get_coordinates')
def get_coordinates():
    return jsonify({'latitude': default_latitude, 'longitude': default_longitude})

if __name__ == '__main__':
    app.run(debug=True)
